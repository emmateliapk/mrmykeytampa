
import { useEffect, useState } from 'react';
import { Check, Phone } from 'lucide-react';
import { fetchServices, fallbackServices } from '../data/services';
import type { Service } from '../data/services';

const TEL = 'tel:850-238-6119';

export default function Services() {
  const [services, setServices] = useState<Service[]>(fallbackServices);

  useEffect(() => {
    let cancelled = false;
    fetchServices().then((data) => {
      if (!cancelled) setServices(data);
    });
    return () => { cancelled = true; };
  }, []);

  return (
    <section id="services" className="bg-brand-charcoal py-20 md:py-28" aria-label="Services">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-14 md:mb-20">
          <p className="section-label mb-3 flex items-center gap-2">
            <span className="inline-block w-6 h-px bg-brand-gold" />
            What We Do
          </p>
          <h2 className="display-heading text-4xl sm:text-5xl md:text-6xl max-w-xl">
            LOCK &amp; KEY<br />
            <span className="text-brand-gold">SOLUTIONS</span>
          </h2>
          <p className="mt-4 text-brand-off-white/60 text-base md:text-lg max-w-xl font-body leading-relaxed">
            From emergency car lockouts to commercial security upgrades — Mr MyKey Tampa handles it all, on-site, on your schedule.
          </p>
        </div>

        {/* Service cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {services.map((svc) => (
            <article
              key={svc.id}
              className="group relative bg-brand-steel/30 border border-brand-steel/50 overflow-hidden hover:border-brand-gold/50 transition-colors duration-300"
            >
              {svc.badge && (
                <div className="absolute top-4 right-4 z-10 bg-brand-gold text-brand-black font-mono text-[10px] font-500 uppercase tracking-widest px-2.5 py-1">
                  {svc.badge}
                </div>
              )}

              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={svc.imageUrl}
                  alt={svc.imageAlt}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-steel/80 to-transparent" />
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="display-heading text-2xl md:text-3xl mb-2">{svc.title}</h3>
                <p className="text-brand-off-white/60 text-sm mb-5 leading-relaxed font-body">{svc.description}</p>
                <ul className="space-y-2">
                  {svc.bullets.map((b) => (
                    <li key={b} className="flex items-start gap-2.5 text-sm text-brand-off-white/80 font-body">
                      <Check size={14} className="text-brand-gold mt-0.5 shrink-0" strokeWidth={2.5} />
                      {b}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Bottom CTA */}
              <div className="px-6 pb-6">
                <a
                  href={TEL}
                  className="flex items-center gap-2 text-brand-gold font-body font-600 text-sm uppercase tracking-wide hover:text-brand-gold-light transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded"
                  aria-label={`Call for ${svc.title}`}
                >
                  <Phone size={14} strokeWidth={2.5} />
                  Call for this service
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
