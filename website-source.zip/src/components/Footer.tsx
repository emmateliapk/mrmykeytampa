
import { Phone, Instagram } from 'lucide-react';

const PHONE = '850-238-6119';
const TEL = 'tel:850-238-6119';
const LOGO_URL = 'https://freename-assets.s3.amazonaws.com/domora-nft-assets/builder-previews/assets/e208dd3f-32d8-4d38-a132-573f0f1a0e70/a1bd7b4b-02a1-4f19-bd13-827c81d07dfc/11c80acc-6d8b-44db-ab86-9988c64af07c/2026-09-24_08.09.29.jpg';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-brand-black border-t border-brand-steel/40 pt-14 pb-8" aria-label="Footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-16 pb-12 border-b border-brand-steel/30">
          {/* Brand */}
          <div>
            <a href="#home" aria-label="Mr MyKey Tampa — Back to top" className="inline-block mb-4">
              <span className="bg-white rounded-lg px-2 py-1 inline-flex items-center">
                <img
                  src={LOGO_URL}
                  alt="Mr Mykey Tampa Locksmith Services"
                  className="h-12 w-auto object-contain"
                />
              </span>
            </a>
            <p className="font-display text-brand-gold text-xl tracking-widest mb-1">Mr MyKey Tampa</p>
            <p className="font-mono text-brand-off-white/40 text-xs tracking-widest uppercase mb-1">24/7 Mobile Locksmith</p>
            <p className="font-mono text-brand-off-white/40 text-xs tracking-widest uppercase mb-4">Tampa Bay, Florida</p>
            <a
              href={TEL}
              className="flex items-center gap-2 text-brand-gold font-body font-600 text-base hover:text-brand-gold-light transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded"
              aria-label={`Call Mr MyKey Tampa at ${PHONE}`}
            >
              <Phone size={15} strokeWidth={2} />
              {PHONE}
            </a>
            <a
              href="https://instagram.com/mrmykey_tampa"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-brand-off-white/60 font-body text-sm hover:text-brand-gold transition-colors duration-150 mt-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded"
              aria-label="Mr MyKey Tampa on Instagram"
            >
              <Instagram size={15} strokeWidth={1.5} />
              @mrmykey_tampa
            </a>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-mono text-brand-off-white/40 text-xs tracking-widest uppercase mb-5">Contact</h3>
            <div className="space-y-3">
              <div>
                <p className="text-brand-off-white/40 text-xs font-mono uppercase tracking-wide mb-1">Phone</p>
                <a
                  href={TEL}
                  className="flex items-center gap-2 text-brand-gold font-body font-600 text-base hover:text-brand-gold-light transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded"
                  aria-label={`Call Mr MyKey Tampa at ${PHONE}`}
                >
                  <Phone size={15} strokeWidth={2} />
                  {PHONE}
                </a>
              </div>
              <div>
                <p className="text-brand-off-white/40 text-xs font-mono uppercase tracking-wide mb-1">Instagram</p>
                <a
                  href="https://instagram.com/mrmykey_tampa"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-brand-off-white/60 font-body text-sm hover:text-brand-gold transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded"
                  aria-label="Mr MyKey Tampa on Instagram"
                >
                  <Instagram size={15} strokeWidth={1.5} />
                  @mrmykey_tampa
                </a>
              </div>
              <div>
                <p className="text-brand-off-white/40 text-xs font-mono uppercase tracking-wide mb-1">Location</p>
                <p className="text-brand-off-white/50 text-sm font-body">Tampa Bay, Florida</p>
              </div>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h3 className="font-mono text-brand-off-white/40 text-xs tracking-widest uppercase mb-5">Quick Links</h3>
            <nav aria-label="Footer navigation">
              <ul className="space-y-2">
                {[
                  { label: 'Home', href: '#home' },
                  { label: 'Services', href: '#services' },
                  { label: 'Why Us', href: '#why-us' },
                  { label: 'Service Area', href: '#service-area' },
                  { label: 'Reviews', href: '#reviews' },
                  { label: 'Contact', href: '#contact' },
                ].map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="text-brand-off-white/50 text-sm font-body hover:text-brand-gold transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-brand-off-white/30 text-xs font-mono">
          <p>&copy; {year} Mr MyKey Tampa. All rights reserved.</p>
          <div className="flex gap-6">
            <a
              href="#"
              className="hover:text-brand-off-white/60 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-brand-gold rounded"
            >
              Privacy Policy
            </a>
            <a
              href="#"
              className="hover:text-brand-off-white/60 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-brand-gold rounded"
            >
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
