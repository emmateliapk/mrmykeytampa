
import { useEffect, useState } from 'react';
import { MapPin, Phone } from 'lucide-react';
import { fetchServiceAreaCities, fallbackServiceAreaCities } from '../data/services';

const TEL = 'tel:850-238-6119';

export default function ServiceArea() {
  const [cities, setCities] = useState<string[]>(fallbackServiceAreaCities);

  useEffect(() => {
    let cancelled = false;
    fetchServiceAreaCities().then((data) => {
      if (!cancelled) setCities(data);
    });
    return () => { cancelled = true; };
  }, []);

  return (
    <section id="service-area" className="bg-brand-charcoal py-20 md:py-28" aria-label="Service area">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left */}
          <div>
            <p className="section-label mb-3 flex items-center gap-2">
              <span className="inline-block w-6 h-px bg-brand-gold" />
              Where We Serve
            </p>
            <h2 className="display-heading text-4xl sm:text-5xl md:text-6xl mb-6">
              TAMPA BAY<br />
              <span className="text-brand-gold">&amp; BEYOND</span>
            </h2>
            <p className="text-brand-off-white/60 text-base md:text-lg leading-relaxed font-body mb-8 max-w-md">
              Mr MyKey Tampa covers the greater Tampa Bay area — from downtown Tampa to Brandon and the surrounding communities. If you&apos;re nearby, we&apos;re on our way.
            </p>
            <a
              href={TEL}
              className="btn-primary inline-flex"
              aria-label="Call Mr MyKey Tampa"
            >
              <Phone size={18} strokeWidth={2.5} />
              Call for Your Area
            </a>
          </div>

          {/* Right: city grid */}
          <div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {cities.map((city) => (
                <div
                  key={city}
                  className="flex items-center gap-2 bg-brand-steel/30 border border-brand-steel/50 px-4 py-3 text-sm font-body text-brand-off-white/70 hover:border-brand-gold/40 hover:text-brand-off-white transition-colors duration-150"
                >
                  <MapPin size={12} className="text-brand-gold shrink-0" strokeWidth={2} />
                  {city}
                </div>
              ))}
            </div>
            <p className="mt-6 text-brand-muted text-xs font-mono tracking-wide">
              Not seeing your city? Call us — we likely cover it.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
