
import { useState, useEffect, useCallback } from 'react';
import { Menu, X, Phone } from 'lucide-react';

const PHONE = '850-238-6119';
const TEL = 'tel:850-238-6119';
const LOGO_URL = 'https://freename-assets.s3.amazonaws.com/domora-nft-assets/builder-previews/assets/e208dd3f-32d8-4d38-a132-573f0f1a0e70/a1bd7b4b-02a1-4f19-bd13-827c81d07dfc/11c80acc-6d8b-44db-ab86-9988c64af07c/2026-09-24_08.09.29.jpg';

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'Services', href: '#services' },
  { label: 'Why Us', href: '#why-us' },
  { label: 'Service Area', href: '#service-area' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Contact', href: '#contact' },
];

export default function Nav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const close = useCallback(() => setOpen(false), []);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'bg-brand-black/95 backdrop-blur-sm border-b border-brand-steel/40' : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a href="#home" className="flex items-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded" aria-label="Mr MyKey Tampa — Home">
            <span className="bg-white rounded-lg px-2 py-1 inline-flex items-center">
              <img
                src={LOGO_URL}
                alt="Mr Mykey Tampa Locksmith Services"
                className="h-12 w-auto object-contain"
              />
            </span>
          </a>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-8" aria-label="Main navigation">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="font-body text-sm font-500 text-brand-off-white/70 hover:text-brand-gold transition-colors duration-150 tracking-wide uppercase focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Desktop CTA */}
          <a
            href={TEL}
            className="hidden lg:flex items-center gap-2 bg-brand-brown text-white font-body font-700 text-sm px-5 py-2.5 uppercase tracking-wide hover:bg-brand-brown-light transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-brown focus-visible:ring-offset-2 focus-visible:ring-offset-brand-black rounded"
            aria-label={`Call Mr MyKey Tampa at ${PHONE}`}
          >
            <Phone size={15} strokeWidth={2.5} />
            {PHONE}
          </a>

          {/* Mobile hamburger */}
          <button
            onClick={() => setOpen((v) => !v)}
            className="lg:hidden p-2 text-brand-off-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
          >
            {open ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </header>

      {/* Mobile drawer */}
      <div
        className={`fixed inset-0 z-40 lg:hidden transition-opacity duration-300 ${open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
        aria-hidden={!open}
      >
        {/* Backdrop */}
        <div className="absolute inset-0 bg-brand-black/80 backdrop-blur-sm" onClick={close} />

        {/* Panel */}
        <div
          className={`absolute top-0 right-0 bottom-0 w-72 bg-brand-charcoal border-l border-brand-steel/40 flex flex-col transition-transform duration-300 ${open ? 'translate-x-0' : 'translate-x-full'}`}
        >
          <div className="flex items-center justify-between px-6 h-16 border-b border-brand-steel/40">
            <span className="bg-white rounded-lg px-2 py-1 inline-flex items-center">
              <img
                src={LOGO_URL}
                alt="Mr Mykey Tampa Locksmith Services"
                className="h-8 w-auto object-contain"
              />
            </span>
            <button onClick={close} className="p-1 text-brand-off-white/70 hover:text-brand-off-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded" aria-label="Close menu">
              <X size={22} />
            </button>
          </div>

          {/* Priority CTA */}
          <div className="px-6 pt-6 pb-4 border-b border-brand-steel/40">
            <a
              href={TEL}
              onClick={close}
              className="flex items-center justify-center gap-3 bg-brand-brown text-white font-body font-700 text-base uppercase tracking-wide py-4 w-full hover:bg-brand-brown-light transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-brown rounded"
              aria-label="Call Rusty now"
            >
              <Phone size={18} strokeWidth={2.5} />
              Call Rusty Now
            </a>
            <p className="text-center text-brand-muted text-xs mt-2 font-mono">Available 24/7 · Tampa Bay</p>
          </div>

          <nav className="flex flex-col px-6 pt-4 gap-1" aria-label="Mobile navigation">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={close}
                className="font-body text-base font-500 text-brand-off-white/80 hover:text-brand-gold py-3 border-b border-brand-steel/20 tracking-wide uppercase transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="mt-auto px-6 pb-8">
            <a
              href="#contact"
              onClick={close}
              className="flex items-center justify-center border-2 border-brand-brown text-brand-brown font-body font-600 text-sm uppercase tracking-wide py-3 w-full hover:bg-brand-brown hover:text-white transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-brown rounded"
            >
              Get a Quote
            </a>
          </div>
        </div>
      </div>
    </>
  );
}
