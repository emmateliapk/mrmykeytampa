
import { supabase, runtimeSchema } from '../lib/supabase';

// ── Shared types ────────────────────────────────────────────────────────────

export interface Service {
  id: string;
  title: string;
  description: string;
  bullets: string[];
  imageUrl: string;
  imageAlt: string;
  badge?: string;
}

export interface Review {
  id: string;
  name: string;
  location: string;
  body: string;
  rating: number;
}

// ── Raw DB row shapes ────────────────────────────────────────────────────────

interface ServiceRow {
  id: string;
  title: string;
  description: string;
  bullets: string[];
  image_url: string;
  image_alt: string;
  badge: string | null;
  sort_order: number;
}

interface CityRow {
  city_name: string;
  sort_order: number;
}

interface ReviewRow {
  id: string;
  reviewer_name: string;
  location: string;
  body: string;
  rating: number;
  sort_order: number;
}

// ── Async fetch functions ────────────────────────────────────────────────────

export async function fetchServices(): Promise<Service[]> {
  const { data, error } = await supabase
    .schema(runtimeSchema)
    .from('services')
    .select('id, title, description, bullets, image_url, image_alt, badge, sort_order')
    .order('sort_order', { ascending: true });

  if (error || !data) {
    console.error('fetchServices error:', error);
    return fallbackServices;
  }

  return (data as ServiceRow[]).map((row) => ({
    id: row.id,
    title: row.title,
    description: row.description,
    bullets: row.bullets ?? [],
    imageUrl: row.image_url,
    imageAlt: row.image_alt,
    badge: row.badge ?? undefined,
  }));
}

export async function fetchServiceAreaCities(): Promise<string[]> {
  const { data, error } = await supabase
    .schema(runtimeSchema)
    .from('service_area_cities')
    .select('city_name, sort_order')
    .order('sort_order', { ascending: true });

  if (error || !data) {
    console.error('fetchServiceAreaCities error:', error);
    return fallbackServiceAreaCities;
  }

  return (data as CityRow[]).map((row) => row.city_name);
}

export async function fetchReviews(): Promise<Review[]> {
  const { data, error } = await supabase
    .schema(runtimeSchema)
    .from('reviews')
    .select('id, reviewer_name, location, body, rating, sort_order')
    .order('sort_order', { ascending: true });

  if (error || !data) {
    console.error('fetchReviews error:', error);
    return fallbackReviews;
  }

  return (data as ReviewRow[]).map((row) => ({
    id: row.id,
    name: row.reviewer_name,
    location: row.location,
    body: row.body,
    rating: row.rating,
  }));
}

// ── Fallback / compatibility constants ───────────────────────────────────────
// Used as in-memory fallbacks if Supabase is unreachable, and kept as named
// exports so any existing import of `services` or `serviceAreaCities` still
// compiles (though components now prefer the async fetch functions).

export const fallbackServices: Service[] = [
  {
    id: 'automotive',
    title: 'Automotive Locksmith',
    description: 'Locked out of your car or need a new key? We come to you — anywhere in Tampa Bay.',
    bullets: [
      'Car lockout service',
      'Transponder key programming',
      'Key fob replacement & programming',
      'Broken key extraction',
      'Ignition repair & replacement',
    ],
    imageUrl:
      'https://images.pexels.com/photos/10566895/pexels-photo-10566895.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    imageAlt: 'Luxury car key fob resting on a textured leather surface',
    badge: 'Most Requested',
  },
  {
    id: 'residential',
    title: 'Residential Locksmith',
    description: 'Home lockouts, rekeying, and lock upgrades handled fast and professionally.',
    bullets: [
      'Home lockout service',
      'Lock rekey & replacement',
      'Deadbolt installation',
      'Smart lock setup',
      'Lost key solutions',
    ],
    imageUrl:
      'https://images.pexels.com/photos/19185833/pexels-photo-19185833.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    imageAlt: 'Charming entrance of a house featuring white double doors',
  },
  {
    id: 'commercial',
    title: 'Commercial Locksmith',
    description: 'Keep your business secure with professional lock and access solutions.',
    bullets: [
      'Commercial lockout service',
      'Master key systems',
      'High-security lock installation',
      'Access control',
      'Lock rekeying after staff changes',
    ],
    imageUrl:
      'https://images.pexels.com/photos/8946078/pexels-photo-8946078.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    imageAlt: 'Minimalistic modern doors on a clean white facade',
  },
];

export const fallbackServiceAreaCities: string[] = [
  'Tampa',
  'Wesley Chapel',
  'Brandon',
  'Riverview',
  'Lutz',
  "Land O' Lakes",
  'New Tampa',
  'Carrollwood',
  'Westchase',
  'Clearwater',
  'St. Petersburg',
  'Zephyrhills',
  'Plant City',
  'Temple Terrace',
  'Odessa',
];

export const fallbackReviews: Review[] = [
  {
    id: '1',
    name: 'James R.',
    location: 'Tampa, FL',
    body: 'Locked out of my car at midnight and they were there in under 20 minutes. Incredibly fast and professional. Will absolutely call again.',
    rating: 5,
  },
  {
    id: '2',
    name: 'Sandra M.',
    location: 'St. Petersburg, FL',
    body: 'Had all my home locks rekeyed after moving in. Fair price, no upselling, and the tech explained everything clearly.',
    rating: 5,
  },
  {
    id: '3',
    name: 'Derek L.',
    location: 'Clearwater, FL',
    body: 'Our office needed a new lock system installed same-day. Mr MyKey came through without any hassle. Highly recommend for businesses.',
    rating: 5,
  },
  {
    id: '4',
    name: 'Tanya W.',
    location: 'Tampa, FL',
    body: 'Super responsive. I called at 7am on a Sunday and someone picked up immediately. Fixed my broken door lock in 30 minutes.',
    rating: 5,
  },
  {
    id: '5',
    name: 'Carlos B.',
    location: 'Brandon, FL',
    body: "Best locksmith experience I've had. Honest pricing, fast arrival, and very friendly. Saved my day when I was locked out.",
    rating: 5,
  },
];

// Legacy named exports kept for any remaining direct imports
export const services = fallbackServices;
export const serviceAreaCities = fallbackServiceAreaCities;
