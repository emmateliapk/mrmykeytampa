
import { Phone, MessageSquare } from 'lucide-react';

const TEL = 'tel:850-238-6119';

export default function EmergencyCTA() {
  return (
    <section
      id="contact"
      className="relative py-20 md:py-28 overflow-hidden"
      style={{ backgroundColor: '#3B2314' }}
      aria-label="Emergency call to action"
    >
      {/* Subtle dark overlay for depth */}
      <div className="absolute inset-0 bg-black/30" aria-hidden="true" />

      {/* Gold top bar */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-brand-gold" />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 text-center">
        {/* Label */}
        <p className="section-label mb-4 flex items-center justify-center gap-2" style={{ color: 'rgba(255,255,255,0.6)' }}>
          <span className="inline-block w-6 h-px bg-brand-gold" />
          Emergency &amp; Non-Urgent
          <span className="inline-block w-6 h-px bg-brand-gold" />
        </p>

        {/* Headline */}
        <h2
          className="font-display uppercase text-white mb-6 leading-none tracking-wide"
          style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}
        >
          LOCKED OUT? NEED A KEY?
        </h2>

        {/* Supporting text */}
        <p
          className="font-body text-lg md:text-xl mb-10 max-w-xl mx-auto leading-relaxed"
          style={{ color: 'rgba(255,255,255,0.85)' }}
        >
          Fast, professional mobile locksmith service throughout Tampa Bay.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          {/* Primary — CALL RUSTY */}
          <a
            href={TEL}
            className="flex items-center justify-center gap-3 bg-brand-gold text-brand-black font-body font-700 text-xl uppercase tracking-wide px-12 py-5 w-full sm:w-auto hover:bg-brand-gold-light active:scale-95 transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2"
            style={{ minHeight: '56px' }}
            aria-label="Call Rusty at Mr MyKey Tampa — 850-238-6119"
          >
            <Phone size={22} strokeWidth={2.5} />
            CALL RUSTY
          </a>

          {/* Secondary — GET A QUOTE */}
          <a
            href="mailto:quote@mrmykeytampa.com"
            className="flex items-center justify-center gap-3 border-2 border-white text-white font-body font-600 text-base uppercase tracking-wide px-10 py-5 w-full sm:w-auto hover:bg-white hover:text-brand-black active:scale-95 transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2"
            style={{ minHeight: '56px' }}
            aria-label="Request a quote from Mr MyKey Tampa"
          >
            <MessageSquare size={18} strokeWidth={2} />
            GET A QUOTE
          </a>
        </div>

        {/* Rusty personal note */}
        <div className="mt-12 inline-flex items-center gap-4 border border-white/20 bg-white/10 px-6 py-4 rounded-sm">
          <div className="w-10 h-10 rounded-full bg-brand-gold/20 border border-brand-gold/40 flex items-center justify-center shrink-0">
            <span className="font-display text-brand-gold text-lg">R</span>
          </div>
          <p className="text-white/70 text-sm font-body text-left leading-snug">
            <span className="text-white font-600">Hi, I&apos;m Rusty.</span> When you call, you&apos;re calling me directly — not a call center. I&apos;ll be there as fast as I can.
          </p>
        </div>
      </div>
    </section>
  );
}
