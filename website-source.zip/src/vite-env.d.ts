
/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL: string;
  readonly VITE_SUPABASE_ANON_KEY: string;
  readonly VITE_RUNTIME_PROJECT_ID: string;
  readonly VITE_RUNTIME_SCHEMA: string;
  readonly VITE_RUNTIME_STORAGE_BUCKET: string;
  readonly VITE_SUPABASE_FUNCTION_NAMESPACE: string;
  readonly VITE_STRIPE_CHECKOUT_FUNCTION: string;
  readonly VITE_STRIPE_PAYMENT_STATUS_FUNCTION: string;
  readonly VITE_STRIPE_PRODUCT_SYNC_FUNCTION: string;
  readonly VITE_STRIPE_WEBHOOK_FUNCTION: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
