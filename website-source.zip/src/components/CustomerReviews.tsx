
import { useEffect, useState } from 'react';
import { Star } from 'lucide-react';
import { fetchReviews, fallbackReviews } from '../data/services';
import type { Review } from '../data/services';

function StarRow({ count }: { count: number }) {
  return (
    <div className="flex gap-0.5 mb-3" aria-label={`${count} out of 5 stars`}>
      {Array.from({ length: count }).map((_, i) => (
        <Star key={i} size={18} className="fill-brand-gold text-brand-gold" />
      ))}
    </div>
  );
}

export default function CustomerReviews() {
  const [reviews, setReviews] = useState<Review[]>(fallbackReviews);

  useEffect(() => {
    let cancelled = false;
    fetchReviews().then((data) => {
      if (!cancelled) setReviews(data);
    });
    return () => { cancelled = true; };
  }, []);

  return (
    <section aria-label="Customer reviews" className="bg-brand-cream py-20 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Heading */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-black mb-3 tracking-tight">
            What Our Customers Say
          </h2>
          <p className="text-brand-steel text-base md:text-lg max-w-xl mx-auto">
            Trusted by Tampa Bay homeowners, drivers, and businesses.
          </p>
        </div>

        {/* Cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review) => (
            <div
              key={review.id}
              className="bg-white rounded-2xl p-6 shadow-md border border-brand-cream flex flex-col"
            >
              <StarRow count={review.rating} />
              <p className="text-brand-charcoal text-sm leading-relaxed flex-1 mb-5">
                &ldquo;{review.body}&rdquo;
              </p>
              <div className="border-t border-brand-cream pt-4">
                <p className="font-semibold text-brand-black text-sm">{review.name}</p>
                <p className="text-xs text-brand-steel mt-0.5">{review.location}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
