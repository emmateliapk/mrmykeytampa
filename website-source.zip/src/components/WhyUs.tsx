
import { Clock, MapPin, Wrench, ShieldCheck } from 'lucide-react';

const reasons = [
  {
    icon: Clock,
    title: '24/7 Availability',
    body: 'Lockouts don\'t keep business hours. Rusty is available around the clock — nights, weekends, and holidays — so you\'re never stranded.',
  },
  {
    icon: MapPin,
    title: 'Truly Mobile',
    body: 'No shop, no waiting room. We come directly to your location anywhere in Tampa Bay — your driveway, parking lot, or roadside.',
  },
  {
    icon: Wrench,
    title: 'Car & Home Expertise',
    body: 'From transponder key programming to residential rekeying, we carry the tools and knowledge to handle modern lock and key systems on the spot.',
  },
  {
    icon: ShieldCheck,
    title: 'A Real Local Business',
    body: 'Mr MyKey Tampa is operated by Rusty — a real person serving his community, not a call center dispatching strangers. You know who\'s coming.',
  },
];

export default function WhyUs() {
  return (
    <section id="why-us" className="bg-brand-black py-20 md:py-28" aria-label="Why choose Mr MyKey Tampa">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left: image + accent */}
          <div className="relative">
            <div className="relative overflow-hidden">
              <img
                src="https://images.pexels.com/photos/35287856/pexels-photo-35287856.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
                alt="Locksmith working with key cutting tools outdoors"
                className="w-full h-80 md:h-[480px] object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-brand-black/60 to-transparent" />
            </div>
            {/* Gold accent block */}
            <div className="absolute -bottom-6 -right-4 md:-right-8 bg-brand-gold p-6 md:p-8 max-w-[200px]">
              <p className="font-display text-brand-black text-4xl md:text-5xl leading-none">24/7</p>
              <p className="font-mono text-brand-black/70 text-xs uppercase tracking-widest mt-1">Always On</p>
            </div>
            {/* Decorative border */}
            <div className="absolute -top-4 -left-4 w-24 h-24 border-t-2 border-l-2 border-brand-gold/40 pointer-events-none" />
          </div>

          {/* Right: reasons */}
          <div>
            <p className="section-label mb-3 flex items-center gap-2">
              <span className="inline-block w-6 h-px bg-brand-gold" />
              Why Mr MyKey Tampa
            </p>
            <h2 className="display-heading text-4xl sm:text-5xl md:text-6xl mb-10">
              THE LOCAL<br />
              <span className="text-brand-gold">DIFFERENCE</span>
            </h2>

            <div className="space-y-8">
              {reasons.map((r) => {
                const Icon = r.icon;
                return (
                  <div key={r.title} className="flex gap-5">
                    <div className="shrink-0 w-10 h-10 border border-brand-gold/40 flex items-center justify-center">
                      <Icon size={18} className="text-brand-gold" strokeWidth={1.5} />
                    </div>
                    <div>
                      <h3 className="font-body font-700 text-brand-off-white text-base mb-1 tracking-wide">{r.title}</h3>
                      <p className="text-brand-off-white/55 text-sm leading-relaxed font-body">{r.body}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
