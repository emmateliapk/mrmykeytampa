
import { Phone } from 'lucide-react';

const TEL = 'tel:850-238-6119';

export default function FloatingCallButton() {
  return (
    <a
      href={TEL}
      className="fixed bottom-6 right-4 z-50 lg:hidden flex items-center gap-2.5 bg-brand-gold text-brand-black font-body font-700 text-sm uppercase tracking-wide px-5 py-3.5 shadow-lg shadow-brand-gold/20 hover:bg-brand-gold-light active:scale-95 transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-black"
      style={{ minHeight: '48px', minWidth: '48px' }}
      aria-label="Call Rusty at Mr MyKey Tampa"
    >
      <Phone size={18} strokeWidth={2.5} />
      CALL RUSTY
    </a>
  );
}
