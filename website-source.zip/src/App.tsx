
import Nav from './components/Nav';
import Hero from './components/Hero';
import Services from './components/Services';
import WhyUs from './components/WhyUs';
import ServiceArea from './components/ServiceArea';
import CustomerReviews from './components/CustomerReviews';
import Testimonials from './components/Testimonials';
import EmergencyCTA from './components/EmergencyCTA';
import Footer from './components/Footer';
import FloatingCallButton from './components/FloatingCallButton';

export default function App() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <Services />
        <WhyUs />
        <ServiceArea />
        <CustomerReviews />
        <Testimonials />
        <EmergencyCTA />
      </main>
      <Footer />
      <FloatingCallButton />
    </>
  );
}
