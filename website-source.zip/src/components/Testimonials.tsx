
import { Star } from 'lucide-react';

// Replace placeholder objects with real Google review data when available
interface ReviewSlot {
  id: number;
}

const reviewSlots: ReviewSlot[] = [
  { id: 1 },
  { id: 2 },
  { id: 3 },
];

export default function Testimonials() {
  return (
    <section id="reviews" className="bg-brand-black py-20 md:py-28" aria-label="Customer reviews">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-14">
          <p className="section-label mb-3 flex items-center gap-2">
            <span className="inline-block w-6 h-px bg-brand-gold" />
            Customer Reviews
          </p>
          <h2 className="display-heading text-4xl sm:text-5xl md:text-6xl">
            WHAT OUR<br />
            <span className="text-brand-gold">CUSTOMERS SAY</span>
          </h2>
          <p className="mt-4 text-brand-off-white/50 text-sm font-mono max-w-md">
            Real reviews from real Tampa Bay customers
          </p>
        </div>

        {/* Review cards — 1 col mobile, 2 col tablet, 3 col desktop */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviewSlots.map((slot) => (
            <div
              key={slot.id}
              className="bg-white border border-gray-200 shadow-sm rounded-sm p-6 flex flex-col gap-4"
              aria-label="Customer review placeholder"
            >
              {/* 5 outlined/empty stars — no rating implied */}
              <div className="flex gap-1" aria-label="Star rating placeholder — not yet rated">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star
                    key={s}
                    size={18}
                    className="text-gray-300"
                    strokeWidth={1.5}
                    fill="none"
                  />
                ))}
              </div>

              {/* Review body placeholder */}
              <div className="flex-1 flex items-center justify-center min-h-[96px] border border-dashed border-gray-300 rounded px-4 py-5 bg-gray-50">
                <p className="text-gray-400 text-xs font-mono text-center tracking-wide uppercase leading-relaxed">
                  REAL CUSTOMER REVIEW WILL APPEAR HERE
                </p>
              </div>

              {/* Reviewer name + source */}
              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <p className="text-gray-500 text-sm font-body">— Customer Name, Tampa Bay</p>

                {/* Google Review badge */}
                <span className="inline-flex items-center gap-1.5 bg-gray-100 border border-gray-200 rounded px-2 py-1">
                  {/* Google "G" monogram */}
                  <span
                    className="font-bold text-xs leading-none"
                    style={{ color: '#4285F4' }}
                    aria-hidden="true"
                  >
                    G
                  </span>
                  <span className="text-gray-500 text-[10px] font-mono uppercase tracking-wide">Google Review</span>
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Leave a review CTA */}
        <div className="mt-10 text-center">
          <a
            href="#"
            className="text-brand-gold/70 hover:text-brand-gold text-sm font-mono underline underline-offset-4 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded"
            aria-label="Leave us a Google Review"
          >
            Leave us a Google Review
          </a>
        </div>
      </div>
    </section>
  );
}
