
import { Phone, ChevronDown } from 'lucide-react';

const TEL = 'tel:850-238-6119';

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex flex-col justify-end overflow-hidden"
      aria-label="Hero — Mr MyKey Tampa 24/7 Mobile Locksmith"
    >
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/13633258/pexels-photo-13633258.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
          alt="Hands on a Toyota steering wheel, closeup inside a vehicle"
          className="w-full h-full object-cover object-center"
          loading="eager"
          fetchPriority="high"
        />
        {/* Gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-brand-black/70 to-brand-black/20" />
        <div className="absolute inset-0 bg-gradient-to-r from-brand-black/60 via-transparent to-transparent" />
      </div>

      {/* Brown accent bar */}
      <div className="absolute top-0 left-0 right-0 h-1" style={{ backgroundColor: '#3B200A' }} />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 pb-20 md:pb-28 pt-32 w-full">
        <div className="max-w-2xl">
          {/* Label */}
          <p className="section-label mb-4 flex items-center gap-2">
            <span className="inline-block w-6 h-px bg-brand-gold" />
            Tampa Bay · Available 24/7
          </p>

          {/* Headline */}
          <h1 className="display-heading text-5xl sm:text-6xl md:text-7xl lg:text-8xl mb-6 leading-none">
            LOCKED OUT?<br />
            <span className="text-brand-gold">WE COME</span><br />
            TO YOU.
          </h1>

          {/* Sub */}
          <p className="font-body text-brand-off-white/80 text-lg md:text-xl mb-8 max-w-lg leading-relaxed">
            Mr MyKey Tampa is your local 24/7 mobile locksmith for car, home, and business lock needs across the Tampa Bay area.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href={TEL}
              className="btn-primary text-lg px-10 py-5"
              aria-label="Call Mr MyKey Tampa now"
            >
              <Phone size={20} strokeWidth={2.5} />
              Call Rusty Now
            </a>
            <a
              href="#contact"
              className="btn-outline text-base"
            >
              Get a Quote
            </a>
          </div>

          {/* Trust signals */}
          <div className="mt-10 flex flex-wrap gap-6 text-brand-off-white/50 text-sm font-mono">
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-brand-gold inline-block" />
              24/7 Emergency Response
            </span>
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-brand-gold inline-block" />
              Mobile — We Come to You
            </span>
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-brand-gold inline-block" />
              Car · Home · Business
            </span>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <a
        href="#services"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 text-brand-off-white/40 hover:text-brand-gold transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded"
        aria-label="Scroll to services"
      >
        <ChevronDown size={28} className="animate-bounce" />
      </a>
    </section>
  );
}
  